﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace app.WebServices.Model
{
    public class IwaywardID
    {
        public string CodeID { get; set; }
    }
   
}