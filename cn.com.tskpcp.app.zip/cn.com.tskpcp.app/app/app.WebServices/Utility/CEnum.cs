﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace app.WebServices.Utility
{
    //枚举定义
    public enum ALARM_ALARMTYPE
    {
        
        WhiteLight,
        YellowLight
    }
  
}
